# image_processing

Description. 
The package image_processing is used to:
	- Processing:
		- Histogram matching
		- Structural similarity
		- Resie image
	- Utils:
		- Read image
		- Save image
		- Plot image, result and histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install image_processing
```

## Author
Quintino Medeiros

## License
[MIT](https://choosealicense.com/licenses/mit/)